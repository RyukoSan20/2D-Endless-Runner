# 2dEndlessRunnerAgate

ini adalah game 2d endless runner

# Penambahan Fitur

1. penambahan musik
2. penambahan efek partikel system
3. mengubah desain UI

# Link Build Game

https://github.com/Mikael2909/2dEndlessRunnerAgate/releases/tag/2d-Endless-Runner-Agate
